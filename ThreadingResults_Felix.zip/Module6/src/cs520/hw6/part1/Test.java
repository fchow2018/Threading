package cs520.hw6.part1;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;

public class Test {
	public static void main(String[] args) {
		InputStreamReader inputStream = null;
		BufferedReader reader = null;

		try {
			String page = "http://norvig.com/big.txt";
			URL urlObject = new URL(page);

			System.out.printf("Protocol (%s), Host (%s)\n",
					urlObject.getProtocol(),
					urlObject.getHost());

			System.out.printf("Port (%s), Default Port (%s)\n",
					urlObject.getPort(),
					urlObject.getDefaultPort());

			System.out.printf("Path (%s), Query (%s), File (%s)\n",
					urlObject.getPath(),
					urlObject.getQuery(),
					urlObject.getFile());

			// Read the data
			StringBuffer buffer = new StringBuffer();
			String inputLine;
			
			inputStream = new InputStreamReader(urlObject.openStream());
			reader = new BufferedReader(inputStream);
			while ((inputLine = reader.readLine()) != null) {
				buffer.append(inputLine.toLowerCase() + "\n");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (inputStream != null) {
					inputStream.close();
				}
				if (reader != null) {
					reader.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	SharedResults sharedResults = new SharedResults();
	SharedResults shared = sharedResults;
	LongTask[] threads = new LongTask[26];
	join();
	//		System.out.print(result);
}

