package cs520.hw6.part1;

import java.util.ArrayList;

public class SharedResults {
	private ArrayList<ResultsEntry> results;

	public SharedResults() {
		results = new ArrayList<>();		
	}

	public synchronized void addToResults(ResultsEntry resultEntry) {
		results.add(resultEntry);
		System.out.print("Thread name: " + Thread.currentThread().getName() + "\nEntry added: " + resultEntry + results);
	}

	public synchronized int getResult(int countSum) {
		return countSum;
	}
}

