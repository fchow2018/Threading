package cs520.hw6.part1;

public class LongTask extends Thread {
	private SharedResults sharedData;
	private StringBuffer inputData;
	private char target;

	public LongTask (SharedResults shared_data, StringBuffer input_data, char target_data, String name){
		super(name);
		shared_data = sharedData;
		input_data = inputData;
		target_data = target;
	}

	public void run() {
		for (SharedResults inputData : target) {
			for (int i = 1; i <= ResultsEntry.getCount(); i++) {
				System.out.print("There are " + ResultsEntry.getCount() + " occurences of " + target);
	        }
		}
		
		/*for (int i = 1; i <= ResultsEntry.getCount(); i++) {
			System.out.print("There are " + ResultsEntry.getCount() + " occurences of " + target);
        }*/
	}

	ResultsEntry countChar;
	ResultsEntry targetChar;
	addToResults();
}
